/**
 * 
 */
/**
 * @author MG
 *
 */
module Secondjavafx {
	requires javafx.web;
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	requires javafx.swing;
	requires javafx.media;
	requires java.sql;
	
	opens Secondjavafx;
}